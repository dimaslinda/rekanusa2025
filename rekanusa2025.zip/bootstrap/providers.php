<?php

return [
    App\Providers\AppServiceProvider::class,
    App\Providers\Filament\SecretPanelProvider::class,
];
